import re

text = ''

with open("Data.txt", "r") as f:
    for line in f:
        if line == '\n' or line.startswith('Page '):
            continue
        
        text += line.rstrip() + ' '

Filtered = filter(None, re.split("\“|\” |; |, |! |\. |\.\n", text))
sentences = list(Filtered)

dataset = {}

for sentence in sentences:
    words_list = sentence.split(' ')
    q = p = words_list[0]

    for word in words_list[1:]:
        p = q
        q = word
        # print(p, q)
        if p in dataset.keys():
            if q in dataset[p]:
                dataset[p][q] += 1
            else:
                dataset[p][q] = 1
        else:
            dataset[p] = {}
            dataset[p][q] = 1
    

# print(len(dataset['Harry']))